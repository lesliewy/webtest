#! /bin/bash
#####################################################
#此脚本用来解析TXN.trc文件                          #
####################################################

#载入相关函数
. analyse_func
. analysetxn_func
####################################################
#             主程序                               #
####################################################
while [ $loopvar -gt 0 ]
do
{
   #执行主菜单函数
   main_menu
   echo -n "please choose [1-5]:"     # -n: 不换行
   read main_choice
   case $main_choice in
   1)
   #执行解析txn文件的函数
   analysetxn
   ;;
   2)
   ;;
   3)
   ;;
   4)
   ;;
   5)
   echo "choose exit"
   while [ $loopvar -gt 0 ]
   do 
   {
     echo -n " Do you want to exit?(y/n):"
     read exit_choice
     case $exit_choice in
     y|yes)
     exit 1
     ;;
     n|no)
     clear
     break 1
     ;;
     esac
    } 
    done
    ;;
    *)
    echo "choose other:"
    echo $main_choice
    ;;
    esac
 }
 done
