#! /bin/bash

# 查询该文件所在的服务.
checkoneline(){
   service=`echo $1|awk -F / '{ 
       i=1
       while(i < NF){
       if (length($i) >= 7) 
          if(substr($i,1,1) == "C" || substr($i,1,1) == "O" || substr($i,1,1) == "S")
             print $i
       i++
       }
   }'` 
#   echo "service:$service"
   if [ -n "$service" ];then
      flag=`grep -i boot a.lst|grep $service`
      if [ -z "$flag" ];then 
         if [ !  `echo $nolistservice|grep -i $service` ];then
            echo "warn: 请查看 $service 服务是否需要重启."
            nolistservice=$nolistservice"|"$service
         fi
      fi
   fi
}

EX_SUCCESS=0
for line in `grep file a.lst`;do
   file=`echo "$line" |cut -d : -f 2` 
   checkoneline "$file"
   # pkg 情况单独, pkg 调用Pkg这种嵌套情况还没考虑.
   if [ `echo $file|grep -i pkg` ];then
      package=`grep $file h|cut -d "|" -f 2`
#      echo "$file is a package: $package"
      for line2 in `grep $package h|cut -d "|" -f 1`; do
         checkoneline "$line2"
      done
   fi
done 

exit $EX_SUCCESS

