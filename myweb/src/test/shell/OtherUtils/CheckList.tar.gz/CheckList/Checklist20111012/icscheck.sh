#! /bin/bash

# icscheck.sh
# 说明: 利用ICS平台程序开发中,代码规范的检查.
#       包括:  Switch 中必须包含Default
# 开始时间: 2011/10/08
# 版本: 0.1.0

USAGE(){
   cat <<- ENDOFUSAGE
Usage:
  1. `basename $0`  file1 file2 file3 ...
  2. `basename $0`  -f file-list            参数 file-list 是一个文件，其中每一行是一个要检查的文件的绝对路径.
ENDOFUSAGE

}
EX_USAGE=64
EX_OK=0

[ "$#" -eq 0 ] && (echo "Usage:`basename $0` file-name";echo "Exit.") && (USAGE exit $EX_USAGE)
while getopts ":f:b" option;do
   case "$option" in
      "f") echo "with option $option,arguments is $OPTARG"
         file_list=$OPTARG
         ;;
      *) echo "no this option "
         USAGE
         exit $EX_USAGE
         ;;
   esac
done

# 没有参数 -f
if [ ! -n "$file_list" ]; then
   all_files=$@
   for file in $all_files;do
      awk -f switch_sed_chk.awk $file  
   done &>checklist.log     # 输出到日志文件.
   exit $EX_OK
fi

# 参数-f
[ -n "$file_list" ] && [ ! -f "$file_list" ] && (echo "指定的列表文件 $file_list 不存在.";echo "Exits.") && exit $EX_USAGE
for file in `cat $file_list`; do
   #检查:  Switch 中必须包含Default
   echo "Switch 检查:"
   awk -f switch_sed_chk.awk $file  

   #检查: 禁止使用UpdateRecord
   echo "UpdateRecord 检查:"
   updaterecord_lineno=`grep -ni updaterecord $file | awk -F : '{print $1}'|tr "\n" " "`
   if [ -n "$updaterecord_lineno" ];then
     echo "$file: 第 $updaterecord_lineno 行包含updaterecord" 
   else
     echo "$file: 检查完毕"
   fi

   #检查: 禁止使用select *
   echo "select * 检查:"
   selectall_lineno=`grep -ni "select *\*" $file | awk -F : '{print $1}'|tr "\n" " "`
   if [ -n "$selectall_lineno" ];then
      echo "$file: 第 $selectall_lineno 行包含select *."
   else 
      echo "$file: 检查完毕."
   fi 

   # 检查: TPEL中禁止使用GWASetMsg,此处利用了文件名规范 *_PKG.XML
   echo "TPEL 中禁止使用GWASetMsg 检查:"
   suffix_pkg=${file:(-7)}                          # 取文件名后7位. ${file: -7} 
   echo "suffix_pkg:$suffix_pkg"
   if [ "$suffix_pkg" == "PKG.XML" ];then
      gsm_inpkg_lineno=`grep -ni "GWASetMsg" $file | awk -F : '{print $1}'|tr "\n" " "` 
   fi
   if [ -n "$gsm_inpkg_lineno" ];then
      echo "$file: 第 $gsm_inpkg_lineno 行包含GWASetMsg."
   else
      echo "$file: 检查完毕."
   fi


done &>checklist.log     # 输出到日志文件.

echo "Completed."
exit $EX_OK
