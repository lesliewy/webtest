#! /bin/bsh

absolutedir=`pwd`
for file in `ls *.XML`;do
   echo "$absolutedir/$file" >> a.list

done
