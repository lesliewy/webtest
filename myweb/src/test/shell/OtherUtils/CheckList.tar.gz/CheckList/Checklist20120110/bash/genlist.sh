#! /bin/bash

absolutedir=`pwd`
for file in `find "$1" -name  "*.XML"`;do
   echo "${file/\/home\/fdadm\//}" >> a.list
done

exit 0
